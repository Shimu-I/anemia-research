# Updated Thesis Sections: Abstract, Chapter 1 (Introduction) and Chapter 2 (Literature Review)

**Thesis:** Beyond the Needle: Attention-Based Multimodal Deep Learning for Anemia Screening Through Ablation Studies and Comparative Benchmarking

## How to use this file

- Every citation is written as `(citation: p-N)`, where `p-N` is the serial number of the paper in `thesis_cited_papers.xlsx`. Several papers in one place are separated by semicolons. Replace each one with your reference style (for example `[12]`) when you add it to the report.
- Only papers from `all_literature_review_updated.xlsx` are cited, and all statements about them follow the abstract, dataset and model columns of that sheet. Please re-check each statement against the full paper before you submit.
- The 12 colored rows (the dataset paper plus the 11 benchmarking papers) are all in the literature review. The 11 benchmarking papers are tagged with their run ID, **B03 to B13**.
- Benchmark numbers come from `benchmark_figures_explained.md` and `benchmark_comparison_data.csv`. "Reference model" means your selected model (BiLSTM pooling + self-attention fusion, image-only).
- Sections 2.1 (Anemia and Its Clinical Assessment) and 2.2 (Deep Learning Foundations) are not repeated here. Keep them as they are and add citations where the old text had `[?]`.
- The old Chapter 2 discussed HemaApp, Das and Bhattacharjee, Appiahene et al. and a CNN+SVM mobile-health study. They are **not** in your xlsx, so I did not use them. If you want them back, add them to the sheet first so they can be verified.
- Chapters 3, 4 and 6, and the old Sections 4.7 and 6.4, still need a benchmarking part (see the end of the chat message for what is affected).

---

# Abstract (updated)

Anemia affects a large part of the world's population, yet its standard diagnosis requires a blood sample and laboratory support that are often unavailable in remote or resource-limited settings. This thesis investigates whether smartphone recordings of the fingertip, the palm and the fingernail can support non-invasive anemia screening, how these sources should be combined, and how the resulting model compares with published methods. Using a public dataset of 909 young adults, ImageNet-pretrained ResNet-18 models were first fine-tuned on each modality separately with patient-level stratified splits. For the video modalities, an ablation then varied the number of sampled frames (8, 16 and 32) and the training strategy (class-imbalance weighting, data augmentation, or both). The best single-modality models reached test accuracies of 73.87% for fingertip videos, 67.27% for nail photographs and 67.20% for palm videos. A tri-modal fusion framework was then studied through a component-wise ablation in which per-modality ResNet-18 encoders were combined by concatenation or self-attention fusion, frame features were aggregated by mean pooling or a bidirectional LSTM, and demographic and symptom variables were optionally added. The ablation was run on a common three-class test set of 123 participants under single-split and five-fold protocols. No component had a consistent effect: six fairly comparable configurations reached a mean five-fold macro-F1 between 0.380 and 0.459, close to the 0.407 of a logistic regression on demographic and symptom variables alone, and no difference was statistically supported. The image-only model with BiLSTM pooling and self-attention fusion had the highest macro-F1 (0.459 ± 0.075; fold-averaged macro AUC-ROC 0.756) and was selected as the provisional reference model. One configuration with much higher scores was found unreliable and excluded.

The reference model was then benchmarked against eleven published methods taken from the anemia-detection and multimodal-fusion literature, each re-implemented on the same three-class task. Six of them were scored on the same fixed test set under five-fold evaluation, and five were run on their own splits. The reference model had the highest macro-F1 of all eleven, but seven methods lay within one standard deviation of it (macro-F1 0.389 to 0.419), and no paired permutation test on the five-fold benchmarks supported a difference from it. The methods differed mainly in their operating point and not in overall quality: the reference model found 14 of 36 anemic participants (sensitivity 0.39) at a specificity of 0.89, whereas a late-fusion ElasticNet average found 30 of 36 (sensitivity 0.83) at a specificity of 0.49. Two re-implementations collapsed to predicting Normal for every participant. The reference model identified only one of the seven participants with moderate anemia. The conclusions are further limited by single-site data, small test sets, differing benchmark protocols and an inconsistency found in the label file used for the binary experiments. The findings indicate that the three recordings contain a detectable signal for anemia and that the reference model is competitive with, but not clearly better than, published methods; its performance is not yet adequate for stand-alone clinical screening.

---

# Chapter 1: Introduction (updated)

Anemia is a reduction in the concentration of hemoglobin, the protein that carries oxygen in red blood cells, below the level required to meet physiological needs. It is among the most widespread hematological conditions worldwide and affects more than one billion people (citation: p-1), with children and pregnant women at particular risk (citation: p-2; p-3). This thesis investigates whether short smartphone recordings of three superficial body sites, namely the fingertip, the palm and the fingernail, can support non-invasive anemia screening when they are analyzed with deep learning, how the information from these sites should be combined, and how the resulting model compares with methods published in the anemia-detection and multimodal-fusion literature. This chapter introduces the problem, identifies the gap that motivates the work, states the objectives and research questions, and outlines how the remainder of the thesis addresses them.

## 1.1 Background and Context

The reference method for diagnosing anemia is the measurement of hemoglobin concentration in a laboratory blood sample (citation: p-1). The procedure is accurate, but it is invasive, inconvenient, painful and resource-intensive, which limits large-scale screening and repeated monitoring (citation: p-4). These requirements are difficult to meet in resource-limited settings (citation: p-5), where screening is therefore least available. A screening method that needs only a smartphone camera would remove most of these obstacles. Its purpose would not be to replace laboratory diagnosis, but to identify people who should be referred for a confirmatory test.

The clinical basis for such a method is long established. Physicians routinely inspect areas such as the conjunctiva for pallor, although this visual examination is subjective and depends on the examiner's experience (citation: p-1). Computer-vision studies have tried to make this assessment objective by classifying anemia from photographs of the conjunctiva, fingernails and palms (citation: p-2; p-6), and smartphone-based approaches have been proposed for fingertip video (citation: p-7), fingernail photographs (citation: p-8) and conjunctival images (citation: p-9). Deep convolutional neural networks have extended this line of work because they learn discriminative features directly from images instead of relying on hand-designed color statistics (citation: p-10; p-5).

## 1.2 Problem Statement

Despite this progress, building a dependable image-based anemia screening model remains difficult, for four reasons that shape the design of this thesis.

First, the visual signal is subtle and is easily confounded by illumination, skin tone, camera settings and the position of the body part. Even camera-related factors such as the exposure time and the aspect ratio of the image have been reported to change the prediction of a conjunctiva-based model (citation: p-9). A model trained on one body site must therefore separate a small color change from large irrelevant variation.

Second, the available labeled data are limited. Studies of non-invasive anemia detection often rely on a few hundred participants or fewer, for example 150 patients of whom only 10 were anemic (citation: p-9), 211 eye images (citation: p-11) or 104 cases (citation: p-12). Anemic participants are usually a minority, so models are prone to overfitting and to favoring the majority class.

Third, a single body site provides only a partial view. Each site is affected by different sources of noise, and a video of the fingertip contains temporal information that a single photograph does not (citation: p-7). Studies that combine several body sites exist (citation: p-1; p-13; p-3), but it is not obvious how much each site contributes, how many video frames are needed, or how the sites should be combined.

Fourth, published methods are hard to compare. Reported accuracies range from about 0.70 on the nail photographs of the dataset used in this thesis (citation: p-10) to more than 0.97 on datasets of young children (citation: p-5; p-2). These values come from different datasets, different label definitions and different evaluation protocols, so they do not show which method would work best on a given dataset.

The central problem addressed in this thesis can therefore be stated as follows: how can fingertip videos, palm videos and fingernail photographs be processed and combined with a deep learning model to detect anemia, what is the individual and joint value of each source of information, and how does the selected model compare with published methods when they are evaluated on the same data and the same task?

## 1.3 Research Gap and Motivation

The literature reviewed in Chapter 2 shows that most image-based anemia studies analyze a single anatomical site, most commonly the conjunctiva, the fingernail or the palm (citation: p-2; p-6). Studies that combine several sources of information typically pair one image type with electronic health records or laboratory-derived variables (citation: p-14; p-15; p-16), or use still photographs of several body sites (citation: p-1; p-13). Work that treats video, and in particular the temporal dimension of a fingertip recording, is comparatively scarce (citation: p-7). The public dataset of Valles-Coral et al. (citation: p-17) is unusual in providing, for the same 909 young adults, a fingertip video, a palm video and a nail photograph together with hemoglobin values, age, sex and symptoms. The published analysis of this dataset that we are aware of concentrates on the nail photographs alone (citation: p-10), so the contribution of the two video modalities, the effect of temporal sampling and aggregation, and the benefit of combining all three sites remain insufficiently characterized.

A second gap concerns comparison. Fusion strategies and attention mechanisms have been studied mainly in other domains, for example late fusion of CT and clinical records (citation: p-18), early, intermediate and late fusion of chest X-rays and tabular metadata (citation: p-19), attentional feature fusion for image classification (citation: p-20) and hybrid fusion of several views (citation: p-21). Their reported results come from other data and cannot be transferred to anemia screening directly. To our knowledge, these methods and the published anemia-detection methods have not been re-implemented and compared on the same three-site dataset under one task definition. These unanswered questions define the gap that this thesis addresses.

The motivation for studying fusion is both practical and methodological. Practically, a screening workflow that records three short clips is inexpensive, and combining sites may reduce the dependence on any single, possibly poorly captured, recording. Methodologically, convolutional networks pretrained on large image collections can be transferred to small medical datasets (citation: p-10), and there are several established ways to merge the resulting representations, from simple concatenation to attention between modalities (citation: p-22; p-23; p-24). Comparing these options under controlled conditions is a sound way to learn which design choices matter. Benchmarking against published methods adds an external reference, so that the performance of the selected model is judged against other approaches and not only against its own variants. This motivates the experimental structure adopted here: first to establish what each modality can achieve alone, then to examine the factors that influence the video modalities, then to test fusion, and finally to benchmark the selected model.

## 1.4 Research Objectives and Questions

The aim of this thesis is to develop and evaluate a deep learning framework that detects anemia from fingertip videos, palm videos and fingernail photographs, to determine which design choices improve its performance, and to compare it with published methods. This aim is pursued through the following objectives.

1. To prepare the public multimodal dataset for learning, including verification of the available files, construction of binary and three-class labels, and patient-level stratified splitting into training, validation and test sets.
2. To establish single-modality baselines in which an ImageNet-pretrained ResNet-18 is fine-tuned separately on each modality.
3. To examine, for the video modalities, the effect of the number of sampled frames and of two training strategies, class-imbalance weighting and data augmentation.
4. To design and compare multimodal fusion models that combine the three modalities, contrasting concatenation with self-attention fusion and mean pooling with bidirectional LSTM aggregation of frame features, with and without demographic and symptom variables.
5. To benchmark the selected model against eleven published methods that were re-implemented on the same three-class task, and to describe how they differ in performance and in error profile.
6. To evaluate all models with standard classification metrics, to compare them with tabular-only baselines, and to state clearly what the evidence does and does not support.

These objectives correspond to five research questions, each of which is answered in Chapter 4.

- **RQ1** How well can each single modality (fingernail photograph, palm video, fingertip video) discriminate anemic from non-anemic participants with a fine-tuned ResNet-18?
- **RQ2** How do the number of sampled frames and the training strategy (class-imbalance weighting, augmentation) affect the video-based models?
- **RQ3** How do concatenation and self-attention fusion of the three modalities compare, and how does the choice of temporal aggregation (mean pooling or bidirectional LSTM) influence the result?
- **RQ4** What do demographic and symptom variables contribute, alone and together with the images?
- **RQ5** How does the selected model compare with published anemia-detection and multimodal-fusion methods when they are re-implemented on the same dataset and task?

## 1.5 Scope and Approach

The study uses one public dataset, collected at a single site with a single smartphone model from participants aged 18 to 25 (citation: p-17). All models developed in this thesis share an ImageNet-pretrained ResNet-18 as the visual encoder. The work is organized in three stages. In the first, single-modality binary classifiers (Normal versus Anemic, the latter combining the mild and moderate categories) are trained and refined through an ablation of frame count and training strategy. In the second, the three modalities are fused in a tri-modal network, and a component-wise ablation of the fusion module, the temporal pooling and the demographic and symptom variables is run in a three-class setting (Normal, Mild, Moderate) under single-split and five-fold protocols, with a binary experiment as a reference. The best-supported configuration is then analysed as the reference model. In the third stage, the reference model is compared with eleven published methods, labelled B03 to B13. Seven of them come from the anemia-detection literature (citation: p-5; p-2; p-13; p-1; p-10; p-14; p-9) and four from the multimodal-fusion and attention literature (citation: p-19; p-20; p-18; p-21). Each method was re-implemented on the same three-class task. Six (B03 to B08) were evaluated with five-fold training on the same fixed test set as the reference model, five-fold cross-validation was used for one nail-only method (B13), and four were run once on their own splits (B09 to B12). Because these protocols differ, the benchmark comparison is read as indicative and not as a ranking with statistical support. Explainability methods, clinical deployment and external validation are outside the scope of the thesis and are discussed as future work.

## 1.6 Contributions

The thesis makes the following contributions, each of which is supported by the experiments in Chapter 4.

- A documented preprocessing and patient-level evaluation pipeline for the three modalities of the dataset, including modality-specific frame selection and nail-bed cropping.
- Single-modality ResNet-18 baselines and an ablation showing how frame count and training strategy affect the palm and fingertip models.
- A tri-modal fusion framework with two interchangeable fusion modules, two temporal aggregation methods and an optional demographic and symptom branch, together with a component-wise ablation study evaluated against tabular-only baselines and a documented selection of a reference model.
- A comparative benchmark of the reference model against eleven re-implemented published methods on one dataset and one task, reported with macro-F1, macro-AUC, per-class F1 and confusion matrices, which shows that the methods differ mainly in their operating point (sensitivity against specificity) and that the reference model leads on macro-F1 only by a margin within the fold-to-fold spread.
- A critical account of the limitations of the evidence, including the small moderate-anemia class, the instability of single-split results, an unreliable experiment that was identified and excluded, the different protocols of the benchmark runs, and an inconsistency identified in the label file used for the binary experiments.

## 1.7 Organization of the Thesis

The remainder of the thesis follows the progression from problem to evidence. Chapter 2 presents the medical and technical background, reviews the literature by theme, describes the eleven methods selected for benchmarking, and positions the thesis relative to the literature. Chapter 3 translates the research questions into a design: the requirements, the dataset and labels, the preprocessing, the single-modality baselines, the ablation study, the fusion framework, the benchmarking setup and the evaluation protocol. Chapter 4 describes the implementation environment, reports the results for each research question, including the benchmark comparison, and interprets them together with the limitations of the evidence. Chapter 5 documents the standards, design constraints, cost analysis and complex engineering problem mapping required by the degree programme. Chapter 6 returns to the research problem, summarizes what has been established and what remains unresolved, and outlines future work.

---

# Chapter 2: Background (updated parts)

*Replace the opening paragraph of Chapter 2 with the paragraph below, keep Sections 2.1 and 2.2, and replace Sections 2.3 to 2.5 with the text that follows.*

Chapter 1 identified the need for a non-invasive anemia screening method, the open questions around combining several body sites, and the lack of a common comparison with published methods. This chapter provides the knowledge required to address those questions. It first summarizes how anemia is defined and recognized clinically, then introduces the deep learning concepts used in the thesis, and finally reviews the literature by theme in order to establish what is already known, what is unresolved, and how that motivates the design in Chapter 3. Eleven of the reviewed studies were re-implemented as benchmarks and are marked with their run identifiers (B03 to B13).

## 2.3 Literature Review

The studies below are grouped by the kind of evidence they use, because the relevant question for this thesis is how far each kind of evidence can take non-invasive anemia detection and multimodal fusion. The review covers 52 papers. They include the dataset paper, the eleven papers that were re-implemented as benchmarks, other anemia-detection studies, and work on multimodal and attention-based fusion from other medical and non-medical fields.

### 2.3.1 Signal-Based and Smartphone-Based Hemoglobin Estimation

Early non-invasive approaches estimated hemoglobin from physical signals. One group combined a broadband light source of nine LEDs with a grating spectrograph and a photodiode array to measure fingertip spectra of 109 volunteers, and predicted hemoglobin with principal component analysis and a back-propagation neural network (citation: p-25). The approach needs custom optical hardware, which limits its use in the field. Smartphone-based work removes the special hardware. A ResNet-18 regression network was trained on stacked frames of one-minute smartphone fingertip videos from 150 anemic patients, with laboratory hemoglobin as reference, and reported an error of 0.81 to 1.39 g/dL against 1.7 g/dL for the HemaApp smartphone method (citation: p-7). A smartphone application for leukonychia counts white spots on the nail with rule-based image processing and flags a nail as anemic above a threshold chosen from ROC analysis (citation: p-8). A study of 150 smartphone photographs of the palpebral conjunctiva (a prospective study of 150 patients, of whom 10 had a hemoglobin value below 11 g/dL) used a segmentation network followed by regression, and its CNN-based model reached a sensitivity of only 20% at a specificity of 99% **(benchmark B13)** (citation: p-9). A third kind of work predicts anemia from tabular values derived from images, such as the percentages of red, green and blue pixels together with the hemoglobin level, and reported a test accuracy of 97% on 104 cases (citation: p-12). Because hemoglobin is itself an input there, the model does not remove the need for a blood measurement. A review of 25 studies on non-invasive hemoglobin prediction concluded that dataset diversity, clinical validation and bias remain open problems and proposed smartphone-based screening and federated learning as directions (citation: p-4). Together, these studies show that fingertip video and smartphone photographs carry hemoglobin-related information. They also show that results depend on the capture conditions and that sensitivity is hard to obtain when anemic participants are few.

### 2.3.2 Image-Based Detection from a Single Body Site

A large body of work classifies anemia from still images of one site. For the fingernail, a multi-input deep network combined a pretrained CNN (EfficientNet B1, EfficientNet B4 or MobileNet V3) with a branch for the a* color feature in the CIELAB space, and reached 97.87% test accuracy with EfficientNet B4 on fingernail images of young children from hospitals in Ghana **(benchmark B03)** (citation: p-5). Machine vision on nail images of the dataset used in this thesis, with a DenseNet169 model, reached an accuracy of 0.6983 and an AUC of 0.7409 and showed a positive correlation with the Rad-67 hemoglobin meter, although the authors noted false negatives **(benchmark B11)** (citation: p-10). For the conjunctiva, one study built a multi-branch CNN optimized with the Hippopotamus Optimization algorithm and multiclass SVMs on 211 eye images, reached 97.06% accuracy and used SHAP and t-SNE for interpretation (citation: p-11). Another compared Naive Bayes, a CNN, SVM, k-NN and a decision tree on conjunctiva, palm and fingernail images of children aged 6 to 59 months in Ghana, with a CNN accuracy of 99.12% and the lowest accuracy (95.4%) for the SVM **(benchmark B07)** (citation: p-2). For the palm, a CNN with multiple channel and spatial attention was applied to 710 palm images that were augmented to 4,260 (citation: p-16). These studies show that each site is informative. They also differ in dataset size, population, capture protocol and evaluation design, so their accuracy values are not directly comparable with one another or with those obtained in this thesis. The very high accuracies in particular come from datasets of young children that are small and augmented, and the descriptions we reviewed do not always state whether the data were split before augmentation, so such values should be interpreted with caution.

### 2.3.3 Multi-Site and Multi-Source Anemia Detection

Several studies combine more than one source. Using only images, one deep learning study combined conjunctiva, palm and fingernail photographs in the Body-Part-Anemia Network (BPANet). It uses a ResNet50 backbone, body-part labels, a fusion attention module and a dual loss that combines regression and classification, and it reported an accuracy of 0.849 and an F1-score of 0.828 on a retrospective dataset of 218 patients, falling to 0.716 and 0.788 on a prospective sample of 101 patients **(benchmark B09)** (citation: p-1). This drop shows how much performance can fall outside the development data. A mobile-oriented system trained three CNNs on images of the mouth, eyes and nails of about 1,000 images and combined them by majority vote **(benchmark B08)** (citation: p-13). A deep learning study on conjunctiva, fingernails, palm and tongue images reported 99% accuracy for MobileNet and 83% for a CNN on a Kaggle dataset of more than 4,000 images (citation: p-3), and a literature review of machine learning on eye, palm and fingernail images identified larger datasets and better algorithms as gaps (citation: p-6).

Other studies pair images with structured data. One fused conjunctiva features extracted with a Reverse Convolution Block Attention Mechanism (RCBAM) with electronic health record features selected by a random forest, and reported 95% accuracy **(benchmark B12, image-only branch)** (citation: p-14). Another combined nail or eye images with numerical blood parameters (MCV, hemoglobin, MCH and gender) in a DenseNet169 two-branch model with 94 to 95% accuracy (citation: p-15), and a third merged palm-image features with tabular blood values (citation: p-16). A framework with three modalities (tabular data, images and genetic markers) used GAN-based augmentation from 1,000 to 2,000 samples and attention-based fusion explained with SHAP (citation: p-26). Most of these studies depend on laboratory parameters, so they do not provide fully non-invasive screening. The studies that fuse several body sites use still photographs and not video.

### 2.3.4 The Dataset Used in This Thesis and Related Work

The dataset used in this thesis, released by Valles-Coral et al., provides fingertip videos, palm videos and nail photographs for 909 young adults aged 18 to 25 from Peru, together with hemoglobin values (measured with a Rad-67 non-invasive device), age, sex and symptoms (citation: p-17). The data paper provides only the raw recordings, so frame extraction and cropping must be designed by the user, and it describes no prediction model of its own. The same group has analysed the nail photographs of this population with DenseNet169, InceptionV3 and Xception, and the best model reached an accuracy of about 0.70 and an AUC of about 0.74 (citation: p-10). This result is the closest published reference for the nail experiments reported here, with the caveat that the data partition may differ. A separate dataset of smartphone fingertip videos with a ResNet-18 model exists (citation: p-7), but it contains 150 anemic patients and addresses hemoglobin regression, so it is not the same data or task.

### 2.3.5 Fusion Strategies in Multimodal Deep Learning

Fusion strategies are commonly classified by the stage at which information is merged. A review of deep learning fusion for multimodal medical image classification describes input fusion, intermediate fusion (single-level, hierarchical and attention-based) and output fusion, and highlights Transformer-based fusion (citation: p-22). A systematic review formalizes intermediate fusion in biomedical multimodal deep learning (citation: p-23), and a taxonomy of fusion strategies reports that deep fusion often outperforms unimodal and shallow approaches (citation: p-24). For imaging combined with electronic health records, a systematic review that screened 985 studies and analysed 17 describes early, joint and late fusion and gives implementation guidelines (citation: p-27). General overviews describe multimodal fusion as information extraction, representation learning and fusion (citation: p-28). The best strategy depends on the task: in human activity recognition with RGB video, optical flow and skeleton data, early fusion performed best (citation: p-29), whereas in pulmonary embolism detection from CT and clinical records, seven fusion architectures were compared and a late fusion model reached an AUROC of 0.947, above the imaging-only and clinical-only models **(benchmark B06)** (citation: p-18). For pneumonia classification from chest X-rays and tabular metadata, intermediate and late fusion with a MobileNetV3-Small backbone performed best over ten repeated runs, with Grad-CAM and LIME used for explanation **(benchmark B04)** (citation: p-19). Newer work fuses images with text through frozen foundation models (citation: p-30), proposes a more efficient attention-based fusion network, motivated by the computational cost of existing models in low-resource settings (citation: p-31), and combines CNN, Transformer and signal encoders with attention-based fusion and SHAP explanations (citation: p-32). These studies show that there is no universally best fusion stage, which is the reason why the present thesis compares concatenation and attention-based fusion on its own data.

*Optional paragraph (delete it if you prefer a shorter review, but it lets you cite more papers).* The term image fusion is also used in a different sense, namely the merging of images from several modalities, such as CT, MRI, PET and SPECT, into a single fused image for visual interpretation. Reviews cover the spatial, transform-domain, deep learning and generative approaches (citation: p-33; p-34; p-35), and individual methods use wavelet and contourlet transforms (citation: p-36; p-37; p-38; p-39), CNN-based feature mapping (citation: p-40) or Transformers (citation: p-41; p-42). Multi-modality fusion has also been applied to segmentation tasks (citation: p-43; p-44). This work produces an image for the clinician and is not a classification model, so it is outside the scope of this thesis, in which fusion means the combination of learned feature vectors for a diagnostic decision.

### 2.3.6 Attention-Based Fusion and Temporal Aggregation

Attention has been proposed as a replacement for simple summation or concatenation when features are combined. p-20 replaces addition and concatenation in skip connections with a multi-scale channel attention module, and an iterative variant adds a second attention stage, with better results than the corresponding baselines on CIFAR-100 and ImageNet **(benchmark B05)** (citation: p-20). The same idea was used in a hierarchical attention UNet for surgical instrument segmentation (citation: p-45). A review of CNN-based multimodal medical image fusion names attention mechanisms and Transformers as future directions (citation: p-46). In multimodal learning, a co-attention scheme with multistep cross-modal fusion was proposed for visual question answering (citation: p-47). Closer to the design used here, a multi-view hybrid CNN-Transformer passes the CNN feature tokens of all views, with a learnable embedding per view, through one Transformer and adds a mutual distillation loss, and it reached a mean AUC-ROC of 0.835 on CheXpert against 0.816 for the best baseline **(benchmark B10)** (citation: p-21). In anemia detection, attention appears as a fusion attention module for body parts (citation: p-1), a reverse convolution block attention mechanism (citation: p-14) and channel and spatial attention for palm images (citation: p-16). For temporal or sequential modelling, a hybrid network with a bidirectional LSTM branch over image patches improved the recognition of lung diseases on chest X-rays (citation: p-48). These studies motivate the comparison of concatenation with self-attention fusion and of mean pooling with a BiLSTM in this thesis, although none of them was evaluated on fingertip or palm video for anemia.

### 2.3.7 Explainability in Medical Deep Learning

Because medical decisions are high-risk, models are expected to explain their predictions. A survey of explainable AI in healthcare categorizes techniques for medical images and text and gives guidelines for their interpretation (citation: p-49). In the anemia studies and fusion studies reviewed above, Grad-CAM, SHAP, LIME and t-SNE have been used to show which image regions or features drive a prediction (citation: p-11; p-19; p-32; p-9). Explainability is outside the scope of this thesis, but it is a natural next step for the models developed here.

### 2.3.8 Blood-Smear-Based Anemia Analysis

A separate line of work analyses microscopy images of blood smears. CNN models with same-domain transfer learning classify red blood cells to support the diagnosis of sickle cell anemia (citation: p-50), shape descriptors with an ensemble of classifiers detect anemic diseases in smear images (citation: p-51), and a neural network on shape variables detects sickle cells and elliptocytes after Hough-transform segmentation (citation: p-52). These methods need a blood sample and a microscope, so they belong to laboratory diagnosis and not to non-invasive screening. They are mentioned only to delimit the problem studied here.

### 2.3.9 Methods Selected for Benchmarking

Eleven of the reviewed studies were re-implemented on the three-class task of this thesis (Normal, Mild and Moderate) and compared with the reference model. They were chosen to cover two kinds of approaches: methods designed for anemia detection and fusion or attention methods from other medical fields that can be transferred to three visual inputs. Because most of them were designed for other data or for a binary decision, they were adapted, and their results describe the adapted version and not necessarily the published method. Table 2.1 lists the methods.

**Table 2.1: Published methods re-implemented as benchmarks.**

| Run | Source paper | Original setting and reported result | Version used in this thesis | Evaluation protocol |
|:--|:--|:--|:--|:--|
| B03 | p-5 | Fingernail images of young children (Ghana); EfficientNet B4 with a* color features, 97.87% test accuracy | EfficientNet-B4 with a* color features, three classes | Five-fold, fixed test set |
| B04 | p-19 | Chest X-ray and tabular metadata, pneumonia; intermediate and late fusion best | MobileNetV3-Small, intermediate-fusion variant | Five-fold, fixed test set |
| B05 | p-20 | CIFAR-100 and ImageNet classification; attention replaces summation and concatenation | Attentional feature fusion with ResNet-18 encoders | Five-fold, fixed test set |
| B06 | p-18 | CT and electronic health records, pulmonary embolism; late fusion AUROC 0.947 | Late fusion with ElasticNet averaging | Five-fold, fixed test set |
| B07 | p-2 | Fingernail, palm and conjunctiva images of children; CNN 99.12%, SVM 95.4% | k-NN on CIELAB color features (other classical models also tested) | Five-fold, fixed test set |
| B08 | p-13 | Mouth, eye and nail images; three CNNs combined by majority vote | Majority vote of three ResNet-18 models | Five-fold, fixed test set |
| B09 | p-1 | Conjunctiva, palm and fingernail images; accuracy 0.849 and F1 0.828 (retrospective) | BPANet adapted to three inputs plus age and sex | Single run, own split |
| B10 | p-21 | CheXpert, Hotels-8k and Landmarks; multi-view hybrid CNN-Transformer | MV-HFMD | Single run, own split |
| B11 | p-10 | 909 nail images of the same population; DenseNet169 accuracy 0.6983, AUC 0.7409 | Nail-only DenseNet169 | Single run, own split |
| B12 | p-14 | EHR and conjunctiva images; RCBAM image features, 95% accuracy | RCBAM-MobileNetV2, image-only fingernail branch | Single run, own split |
| B13 | p-9 | Palpebral conjunctival images; CNN with GeM pooling | EfficientNet-B0 with GeM pooling on nail photographs | Five-fold cross-validation over all nail participants |

Three of these methods (B03, B07 and B12) report accuracies of 95% or higher on other datasets, and one (B11) was developed on the nail photographs of the same dataset. The different data, label definitions and protocols mean that the published values cannot be ranked against the results obtained here, which is why the re-implementation on one dataset was needed.

## 2.4 Positioning of This Thesis

The literature supports four observations. First, each of the nail, palm and fingertip sites is individually informative, and deep networks are a natural tool for analyzing them (citation: p-10; p-7; p-2). Second, most published models use one site, or one image type plus clinical records, and the few studies that fuse several body sites use still photographs, so the value of combining video-based sites recorded with the same device on an open dataset is not well quantified (citation: p-1; p-13; p-14; p-17). Third, the temporal information in video is exploited by signal-processing methods and by a regression network on fingertip video (citation: p-7) but is less often studied with learned frame-level features, and little is known about how many frames are needed or whether sequence modeling outperforms simple averaging. Fourth, fusion and attention methods from other medical fields (citation: p-18; p-19; p-20; p-21) and published anemia-detection methods (citation: p-5; p-2; p-1; p-13) report accuracy on different data and with different protocols, and the sensitivity of non-invasive models can be low when anemic participants are few (citation: p-9; p-10).

This thesis addresses these points on a dataset that provides all three visual modalities per participant. It contributes a systematic comparison of frame sampling and training strategies for the video modalities, a fusion framework and component-wise ablation that compare concatenation with self-attention, mean pooling with a BiLSTM and the effect of demographic and symptom variables, the selection of a reference model, and a benchmark in which eleven published methods are re-implemented on the same dataset and task. It does not claim to be the first work to combine visual sites, and its conclusions are limited by the single-site, single-device dataset and by the different protocols of the benchmark runs.

## 2.5 Summary

Anemia is defined by hemoglobin thresholds, and the labels used here follow locally defined thresholds applied to non-invasive measurements. Deep networks pretrained with transfer learning, temporal aggregation of frame features and intermediate fusion provide the technical toolkit. The literature shows that single sites, signal-based methods and fusion with clinical records are informative, but it leaves open how fingertip video, palm video and nail photographs should be combined and how published methods compare on one common dataset. Eleven studies were selected for re-implementation as benchmarks. Chapter 3 therefore designs experiments that first measure each modality, then study the factors affecting the video modalities, then compare fusion strategies, and finally benchmark the selected model against these published methods.

---


# Appendix: Citation key (p-N to paper)

| Serial | Paper title | Benchmark run |
|:--|:--|:--|
| p-1 | Deep Learning-Based Model for Non-invasive Hemoglobin Estimation via Body Parts Images: A Retrospective Analysis and a Prospective Emergency Department Study | B09 |
| p-2 | Iron deficiency anemia detection using machine learning models: A comparative study of fingernails, palm and conjunctiva of the eye images | B07 |
| p-3 | Anaemia Detection using Deep Learning by processing Conjunctiva, Fingernails, Palm and Tongue Images |  |
| p-4 | Non-Invasive Hemoglobin prediction: A machine learning approach |  |
| p-5 | A Multi-input Deep Neural Network Framework for Non-invasive Detection of Anemia using Finger Nail Images | B03 |
| p-6 | Anemia Detection from Eyes, Palm and Fingernails with Machine Learning Models |  |
| p-7 | Fingertip Video Dataset for Non-Invasive Diagnosis of Anemia Using ResNet-18 Classifier |  |
| p-8 | Image-Based Sensing of Leukonychia for Early Diagnosis of Anemia Using a Smartphone Application |  |
| p-9 | Machine/deep learning-assisted hemoglobin level prediction using palpebral conjunctival images | B13 |
| p-10 | Machine vision model using nail images for non-invasive detection of iron deficiency anemia in university students | B11 |
| p-11 | An Explainable AI and Optimized Multi-Branch Convolutional Neural Network Model for Eye Anemia Diagnosis |  |
| p-12 | A Neural Network Optimization Approach for Anemia Prediction Using Image Pixels and Hemoglobin Data |  |
| p-13 | Iron Deficiency Anemia Detection Using Deep CNN and Ensemble Learning | B08 |
| p-14 | Enhancing anemia detection through multimodal data fusion: a non-invasive approach using EHRs and conjunctiva images | B12 |
| p-15 | Multimodal Anemia Detection Using Nail and Eye Images with Numerical Parameters |  |
| p-16 | Revolutionizing anemia detection: integrative machine learning models and advanced attention mechanisms |  |
| p-17 | Non-invasive multimodal dataset for the detection of iron deficiency anemia in young adults: fingertip videos, palm videos, and nail photographs | Dataset |
| p-18 | Multimodal fusion with deep neural networks for leveraging CT imaging and electronic health record: a case-study in pulmonary embolism detection | B06 |
| p-19 | Exploring Fusion Strategies for Multi-Modal Pneumonia Classification with Modality-Specific Explainability | B04 |
| p-20 | Attentional Feature Fusion | B05 |
| p-21 | Multi-view Classification Using Hybrid Fusion and Mutual Distillation | B10 |
| p-22 | A review of deep learning-based information fusion techniques for multimodal medical image classification |  |
| p-23 | A Systematic Review of Intermediate Fusion in Multimodal Deep Learning for Biomedical Applications |  |
| p-24 | Multimodal deep learning for biomedical data fusion: a review |  |
| p-25 | Non-invasive prediction of hemoglobin levels by principal component and back propagation artificial neural network |  |
| p-26 | Enhancing Anaemia Prediction Through Multi-Modal Data Integration and Generative Learning |  |
| p-27 | Fusion of medical imaging and electronic health records using deep learning: a systematic review and implementation guidelines |  |
| p-28 | Research and Application of Multimodal Data Fusion in Medical Images |  |
| p-29 | Early vs Late Fusion in Multimodal Convolutional Neural Networks |  |
| p-30 | MedFMIT: A Foundation Model-Driven Multimodal Fusion Method for Image-Text Disease Diagnosis |  |
| p-31 | HyPCA-Net: Advancing Multimodal Fusion in Medical Image Analysis |  |
| p-32 | Explainable Multimodal Deep Learning Framework for Early Disease Diagnosis |  |
| p-33 | A review on multimodal medical image fusion: Compendious analysis of medical modalities, multimodal databases, fusion techniques and quality metrics |  |
| p-34 | A Review of Multimodal Medical Image Fusion Techniques |  |
| p-35 | Generative AI in Multimodal Medical Image Fusion: A Comparative Analysis of GANs, VAEs, and DDPMs |  |
| p-36 | A Multi-Modal Medical Image Fusion Technique Using Structural Similarity Index Measure and Correlation Coefficient |  |
| p-37 | A Recent Advancements in Multi-Modal Medical Image Fusion Techniques using SWT, NSST, NSCT, and CNN |  |
| p-38 | An Enhanced Multi-Modal Medical Image Fusion Technique using Stationary Wavelet Transform and Method Noise based Wiener Filter |  |
| p-39 | Multimodal Medical Image Registration and Fusion for Quality Enhancement |  |
| p-40 | Multimodal Medical Image Fusion using Hybrid Layer Decomposition with CNN-based Feature Mapping and Structural Clustering |  |
| p-41 | MACTFusion: Lightweight Cross Transformer for Adaptive Multimodal Medical Image Fusion |  |
| p-42 | MATR: Multimodal Medical Image Fusion via Multiscale Adaptive Transformer |  |
| p-43 | A review: Deep learning for medical image segmentation using multi-modality fusion |  |
| p-44 | NMD-FusionNet: a multimodal fusion-based medical imaging-assisted diagnostic model for liver cancer |  |
| p-45 | Hierarchical Attentional Feature Fusion for Surgical Instrument Segmentation |  |
| p-46 | A Review of Deep Learning-based Multi-modal Medical Image Fusion |  |
| p-47 | Cross-Modal Multistep Fusion Network With Co-Attention for Visual Question Answering |  |
| p-48 | Enhancing lung diseases recognition through CNN-RNN methodologies |  |
| p-49 | Survey of Explainable AI Techniques in Healthcare |  |
| p-50 | Deep Learning Models for Classification of Red Blood Cells in Microscopy Images to Aid in Sickle Cell Anemia Diagnosis |  |
| p-51 | Detection of the Top Anemic Diseases in Blood Smear Images Using Image Quantization Followed by Ensemble of Classifiers |  |
| p-52 | Detection of some anaemia types in human blood smears using neural networks |  |
